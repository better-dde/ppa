/* Do not modify this file. Changes will be overwritten.                      */
/* Generated automatically by the ASN.1 to Wireshark dissector compiler       */
/* packet-smrse.h                                                             */
/* asn2wrs.py -b -p smrse -c ./smrse.cnf -s ./packet-smrse-template -D . -O ../.. SMRSE.asn */

/* Input file: packet-smrse-template.h */

#line 1 "./asn1/smrse/packet-smrse-template.h"
/* packet-smrse.h
 * Routines for SMRSE Short Message Relay Service packet dissection
 *   Ronnie Sahlberg 2004
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_SMRSE_H
#define PACKET_SMRSE_H

/*#include "packet-smrse-exp.h"*/

#endif  /* PACKET_SMRSE_H */

