/* Do not modify this file. Changes will be overwritten.                      */
/* Generated automatically by the ASN.1 to Wireshark dissector compiler       */
/* packet-acp133.h                                                            */
/* asn2wrs.py -b -p acp133 -c ./acp133.cnf -s ./packet-acp133-template -D . -O ../.. acp133.asn MHSDirectoryObjectsAndAttributes.asn */

/* Input file: packet-acp133-template.h */

#line 1 "./asn1/acp133/packet-acp133-template.h"
/* packet-acp133.h
 * Routines for ACP133 specific syntaxes in X.500 packet dissection
 * Graeme Lunt 2005
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_ACP133_H
#define PACKET_ACP133_H

/* #include "packet-acp133-exp.h" */

#endif  /* PACKET_ACP133_H */
