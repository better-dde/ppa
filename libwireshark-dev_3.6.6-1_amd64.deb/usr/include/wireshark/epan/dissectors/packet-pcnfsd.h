/* packet-pcnfsd.h
 *
 * Wireshark - Network traffic analyzer
 * By Gerald Combs <gerald@wireshark.org>
 * Copyright 1998 Gerald Combs
 *
 *
 * SPDX-License-Identifier: GPL-2.0-or-later
 */

#ifndef PACKET_PCNFSD_H
#define PACKET_PCNFSD_H

#define PCNFSD_PROGRAM 150001

#endif

