var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Data Structures",url:"annotated.html",children:[
{text:"Data Structures",url:"annotated.html"}]},
{text:"Files",url:"files.html",children:[
{text:"File List",url:"files.html"},
{text:"Globals",url:"globals.html",children:[
{text:"All",url:"globals.html",children:[
{text:"b",url:"globals.html#index_b"},
{text:"d",url:"globals_d.html#index_d"}]},
{text:"Functions",url:"globals_func.html",children:[
{text:"b",url:"globals_func.html#index_b"},
{text:"d",url:"globals_func_d.html#index_d"}]},
{text:"Typedefs",url:"globals_type.html"},
{text:"Enumerations",url:"globals_enum.html"},
{text:"Enumerator",url:"globals_eval.html"},
{text:"Macros",url:"globals_defs.html"}]}]}]}
