var structps__alignment__s =
[
    [ "d2p", "structps__alignment__s.html#a0c5367539e2ff9e5808672445c0a1303", null ],
    [ "sseq", "structps__alignment__s.html#aa4b417c284b9e331431ea7a433f47e19", null ],
    [ "state", "structps__alignment__s.html#a1a62f5fce26879f312588de04c010538", null ],
    [ "word", "structps__alignment__s.html#af0a14378c50f80560198883436a84409", null ]
];