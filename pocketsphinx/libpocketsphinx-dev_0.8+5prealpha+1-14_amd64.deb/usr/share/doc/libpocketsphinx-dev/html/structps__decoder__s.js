var structps__decoder__s =
[
    [ "acmod", "structps__decoder__s.html#af834d2bc1d44c1d9ef607b025413a0b8", null ],
    [ "config", "structps__decoder__s.html#a0565ed97b32408bd05c8104f020cef05", null ],
    [ "d2p", "structps__decoder__s.html#ae6515cbc261686f3f3bbd95719f79793", null ],
    [ "dict", "structps__decoder__s.html#aef6228c17907cc1d0cef835b238b5d91", null ],
    [ "lmath", "structps__decoder__s.html#abd17fe329f2fb219c5a534f3217c5b95", null ],
    [ "mfclogdir", "structps__decoder__s.html#a8bb5ef8791798b8dd9bc82b1ec016663", null ],
    [ "n_frame", "structps__decoder__s.html#a2886b321c576c7def449ebb2f37899fd", null ],
    [ "perf", "structps__decoder__s.html#ab42d1d1e300d2a6df5dd3cd796a27d43", null ],
    [ "phone_loop", "structps__decoder__s.html#a0c6d141d7a71a1287be00a1ebcc7643d", null ],
    [ "pl_window", "structps__decoder__s.html#a0f0a6681ffd98af789f6bed556c814e4", null ],
    [ "rawlogdir", "structps__decoder__s.html#aa2610c52a9267ee18ca095169bf34bfd", null ],
    [ "refcount", "structps__decoder__s.html#aa5ab90180288b6c9039eb86b496f76aa", null ],
    [ "search", "structps__decoder__s.html#ad337270efc93613cf8dd7594f6515799", null ],
    [ "searches", "structps__decoder__s.html#a43bca42790684eefb8d01a0aef6fa530", null ],
    [ "senlogdir", "structps__decoder__s.html#a0ed3476113fe3d63b13ac5e8da3f3b4f", null ],
    [ "uttno", "structps__decoder__s.html#a0f597370dd162c2799efe216c9b991fc", null ]
];