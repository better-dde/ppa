var structciphone__t =
[
    [ "filler", "structciphone__t.html#a96e20b175c00c4edcd75d922dba067cd", null ],
    [ "name", "structciphone__t.html#a2327c5f09fa245c25926c718fdab642d", null ]
];