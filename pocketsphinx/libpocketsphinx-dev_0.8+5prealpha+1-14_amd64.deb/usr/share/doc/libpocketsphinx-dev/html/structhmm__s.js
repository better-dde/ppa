var structhmm__s =
[
    [ "bestscore", "structhmm__s.html#a574850d7092b1e574addf0027b32ea61", null ],
    [ "ctx", "structhmm__s.html#aa47f90a8a9387d4f721cf0de9129b059", null ],
    [ "frame", "structhmm__s.html#ab89d10923ba5a0dc14dc46d76d8daaaf", null ],
    [ "history", "structhmm__s.html#ab7be2a31a64eb152eee76b5192ad03e7", null ],
    [ "mpx", "structhmm__s.html#a25329f2f580cbdbe37be29bc9c2352be", null ],
    [ "n_emit_state", "structhmm__s.html#a6a2b5c90489a11d79e4c65984b69bf7b", null ],
    [ "out_history", "structhmm__s.html#a849e7be0748c36446c2f9e72088efab4", null ],
    [ "out_score", "structhmm__s.html#a9d9c7fc2468f7725cd0d8fcc7d731f7b", null ],
    [ "score", "structhmm__s.html#a5aa78f8b09547dc90d83fa1e3d8cf3c3", null ],
    [ "senid", "structhmm__s.html#abbe5d689b86ce9d3c5dfa2290a33285b", null ],
    [ "ssid", "structhmm__s.html#ad4b029868ba7dd9c27e7be2067651be6", null ],
    [ "tmatid", "structhmm__s.html#a041bb6bd205ce1e0e5e1082d2c8a3586", null ]
];