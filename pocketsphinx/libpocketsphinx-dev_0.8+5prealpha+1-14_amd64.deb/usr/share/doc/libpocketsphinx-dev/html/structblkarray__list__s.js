var structblkarray__list__s =
[
    [ "blksize", "structblkarray__list__s.html#aeb11389e46f0291edfc32821480c2987", null ],
    [ "cur_row", "structblkarray__list__s.html#ab97187e26d64cdd3c69d8cf1a502e783", null ],
    [ "cur_row_free", "structblkarray__list__s.html#a085aeaf09d4488758c6ff65914a0a8c5", null ],
    [ "maxblks", "structblkarray__list__s.html#aa3072b52f230fc0aab19c5c87a98b090", null ],
    [ "n_valid", "structblkarray__list__s.html#aca987591ab1fa1c1aa4d7c099966789c", null ],
    [ "ptr", "structblkarray__list__s.html#ad757cd3031570530fd7de80bc5415fd4", null ]
];