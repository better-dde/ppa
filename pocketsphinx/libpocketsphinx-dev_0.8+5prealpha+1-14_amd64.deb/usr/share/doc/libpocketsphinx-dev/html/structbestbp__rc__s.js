var structbestbp__rc__s =
[
    [ "lc", "structbestbp__rc__s.html#a33fd8891076deb0d592e038cddca66a4", null ],
    [ "path", "structbestbp__rc__s.html#a3cc3a67aa32da9669c5305f7ebb2e7ce", null ],
    [ "score", "structbestbp__rc__s.html#a22fb17e130599acbde1fac4debcca469", null ]
];