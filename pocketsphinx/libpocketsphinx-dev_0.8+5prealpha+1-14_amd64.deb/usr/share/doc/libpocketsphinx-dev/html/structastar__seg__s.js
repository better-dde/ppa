var structastar__seg__s =
[
    [ "base", "structastar__seg__s.html#a1703209b29e19fb37ba2a96e0afd4ea2", null ],
    [ "cur", "structastar__seg__s.html#ac61107dec9190e1a22bbe13ba5d1601c", null ],
    [ "n_nodes", "structastar__seg__s.html#af110ca07eba368ea1cdb098612fe0137", null ],
    [ "nodes", "structastar__seg__s.html#afaef510ccfb44366e753f1213beb0141", null ]
];