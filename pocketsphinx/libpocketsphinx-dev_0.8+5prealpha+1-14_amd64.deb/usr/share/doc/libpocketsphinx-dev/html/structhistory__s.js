var structhistory__s =
[
    [ "ef", "structhistory__s.html#a59e1a1053ba224c4d015f08192c7fd96", null ],
    [ "hist", "structhistory__s.html#a0e9457246e140d8af571eea044178551", null ],
    [ "phmm", "structhistory__s.html#a548a5d7505c78278114ab9b1d5e0ceaa", null ],
    [ "score", "structhistory__s.html#af24720abad5e2e17a99c5aeffa7dc95e", null ],
    [ "tscore", "structhistory__s.html#a09096eb94eba8ad29dc19f231192a24b", null ]
];