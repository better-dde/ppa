var structps__latlink__s =
[
    [ "alpha", "structps__latlink__s.html#ad2f031d271f1d875223aae33116d3f40", null ],
    [ "ascr", "structps__latlink__s.html#ae8a94ce1afb49292b044a0d4ba42b46d", null ],
    [ "best_prev", "structps__latlink__s.html#a8a3ffc0a780a09f8852cbe78c475809e", null ],
    [ "beta", "structps__latlink__s.html#a4c27cd5d4f514832d3d46993e2ee87df", null ],
    [ "ef", "structps__latlink__s.html#a59e2bf9a1c0dd6ce4ac76a17c58fbe36", null ],
    [ "from", "structps__latlink__s.html#ab0912c26d1472b4c5c07042c19ffb979", null ],
    [ "path_scr", "structps__latlink__s.html#a704fcfbdb57b1461325544c782289599", null ],
    [ "to", "structps__latlink__s.html#a782a15b1aeabf68983ca521e51f2c1e1", null ]
];