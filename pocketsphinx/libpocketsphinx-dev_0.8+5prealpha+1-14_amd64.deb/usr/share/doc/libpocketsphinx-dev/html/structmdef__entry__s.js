var structmdef__entry__s =
[
    [ "cd", "structmdef__entry__s.html#a392c05c1061e5972d2a563cf3dabbaab", null ],
    [ "ci", "structmdef__entry__s.html#a24e5db7af5e705b310e82154055043ec", null ],
    [ "ctx", "structmdef__entry__s.html#a8871e34a41ee5f75a6352f3edfe2b0c5", null ],
    [ "filler", "structmdef__entry__s.html#aec019376c0052994e423ca5594913e2e", null ],
    [ "info", "structmdef__entry__s.html#a720c96c23083115ef7f5f707652ed306", null ],
    [ "reserved", "structmdef__entry__s.html#ac8575eaa8687c2d83944da551a262e32", null ],
    [ "ssid", "structmdef__entry__s.html#a12986649de9c59de3cc805e375b2c9a2", null ],
    [ "tmat", "structmdef__entry__s.html#a90758df5d6eb00d3a70135ac4475c7a1", null ],
    [ "wpos", "structmdef__entry__s.html#a701230279f3dc157f4a9f9dc484a6900", null ]
];