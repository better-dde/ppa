var structkws__detection__s =
[
    [ "ascr", "structkws__detection__s.html#a5432a3f86147077fe0ea6aa3abf945e7", null ],
    [ "ef", "structkws__detection__s.html#a27ac2a369db9d19b829a75cbb8f4952a", null ],
    [ "keyphrase", "structkws__detection__s.html#aac9c2d44efee9e97eb13d0e6304763d5", null ],
    [ "prob", "structkws__detection__s.html#ad31001efba99198b76bdef6d9349e754", null ],
    [ "sf", "structkws__detection__s.html#a156d454d921e43866d0e2cc36f8a2322", null ]
];