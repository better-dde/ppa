var structkws__detections__s =
[
    [ "detect_list", "structkws__detections__s.html#a96d224eef9abcc3029e0f8f20e5d6bcf", null ]
];