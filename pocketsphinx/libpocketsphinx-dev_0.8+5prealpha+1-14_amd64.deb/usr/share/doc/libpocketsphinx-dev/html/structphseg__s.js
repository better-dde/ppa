var structphseg__s =
[
    [ "ci", "structphseg__s.html#af5f7284a68f194d1aa2ca76e28b1dea9", null ],
    [ "ef", "structphseg__s.html#a478a1e355e8304bcb82008c8e4780a07", null ],
    [ "score", "structphseg__s.html#a6ae2b5307a7cad3a5f2dad8b00824889", null ],
    [ "sf", "structphseg__s.html#a82ba17fadb468176f5bfc741fffee991", null ],
    [ "tscore", "structphseg__s.html#a9e8752871085308730328f50ef5cb420", null ]
];