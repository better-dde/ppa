var structkws__keyphrase__s =
[
    [ "hmms", "structkws__keyphrase__s.html#a51271131b1a0ea63aec3f4efb68a52a2", null ],
    [ "n_hmms", "structkws__keyphrase__s.html#a80f4c3ca2a0741b2550f744684cd887d", null ],
    [ "threshold", "structkws__keyphrase__s.html#a403e2768765e9cd3896e6a772d832dce", null ],
    [ "word", "structkws__keyphrase__s.html#ab75a1433c652de3692794513566d3388", null ]
];