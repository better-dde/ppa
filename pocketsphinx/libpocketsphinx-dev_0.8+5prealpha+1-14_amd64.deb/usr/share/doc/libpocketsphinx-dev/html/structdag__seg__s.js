var structdag__seg__s =
[
    [ "base", "structdag__seg__s.html#a72f90e137c1f83ab3df6ecd5e1b6dc71", null ],
    [ "cur", "structdag__seg__s.html#a0fed697e06d12e5a0405fdcb0d97faf1", null ],
    [ "links", "structdag__seg__s.html#a5fcc22d787e4db1bdc728ff8faead738", null ],
    [ "n_links", "structdag__seg__s.html#a2a858ea6ef051074be2bd1716a4939fb", null ],
    [ "norm", "structdag__seg__s.html#a4517656eeaa40d33109d39a251a75dea", null ]
];