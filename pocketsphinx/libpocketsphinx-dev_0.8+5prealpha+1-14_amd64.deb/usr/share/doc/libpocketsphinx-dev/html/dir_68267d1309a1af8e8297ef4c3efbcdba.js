var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "libpocketsphinx", "dir_8d034a1e03e98d9b7ac467250bbebdea.html", "dir_8d034a1e03e98d9b7ac467250bbebdea" ]
];