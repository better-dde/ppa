var structmdef__t =
[
    [ "cd2cisen", "structmdef__t.html#ae2ba90b39a79603022daae3c9270a0b7", null ],
    [ "ciphone", "structmdef__t.html#aae4a51202b87f71394b6c5b3138b77c7", null ],
    [ "ciphone_ht", "structmdef__t.html#a1091b9f34193255ccf6038d75523187b", null ],
    [ "n_ci_sen", "structmdef__t.html#a68c3cc85b849363609fd5dadf412a38c", null ],
    [ "n_ciphone", "structmdef__t.html#af460d8d703782cf50ed99164cee17347", null ],
    [ "n_emit_state", "structmdef__t.html#a4a7ffa9d1b9a95a3bf3cca7bd955020a", null ],
    [ "n_phone", "structmdef__t.html#a987f0b9bc4c951ac031f5d283960bd9f", null ],
    [ "n_sen", "structmdef__t.html#a966e28ae25bd8e766dbe81549cbdcd36", null ],
    [ "n_sseq", "structmdef__t.html#ad9afd537734fe1f336e20218da28fb2c", null ],
    [ "n_tmat", "structmdef__t.html#a44d1d9fd99db66f1c37937e89172fed9", null ],
    [ "phone", "structmdef__t.html#a2b9aaf78e5648fe14655d1fe8da5f164", null ],
    [ "sen2cimap", "structmdef__t.html#a4aafd791a1e1adaa9b5b28bf0cfbd624", null ],
    [ "sil", "structmdef__t.html#acc9a57b57bbecaef55cc72be57b875f6", null ],
    [ "sseq", "structmdef__t.html#a2472170a66d451d2d4873a9a6e64adc7", null ],
    [ "wpos_ci_lclist", "structmdef__t.html#a5dd5c3d3058a314f4c971a14d1df5f38", null ]
];