var structstate__align__hist__s =
[
    [ "id", "structstate__align__hist__s.html#a74cb4b079e03059eb0b02cb17bcadb5e", null ],
    [ "score", "structstate__align__hist__s.html#aa8c7206b0491eefdfa2eaaf5a2834652", null ]
];