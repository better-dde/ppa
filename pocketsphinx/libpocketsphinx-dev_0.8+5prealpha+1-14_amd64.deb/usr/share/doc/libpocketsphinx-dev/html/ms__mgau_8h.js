var ms__mgau_8h =
[
    [ "ms_mgau_model_t", "structms__mgau__model__t.html", "structms__mgau__model__t" ],
    [ "ms_mgau_gauden", "ms__mgau_8h.html#a95f75d32387d89eb6fa2bc65e032d34c", null ],
    [ "ms_mgau_senone", "ms__mgau_8h.html#a182da1c0e7872e853566f7728001d00c", null ],
    [ "ms_mgau_topn", "ms__mgau_8h.html#acad38d81d6485f2aad5176f8f4283579", null ],
    [ "ms_cont_mgau_frame_eval", "ms__mgau_8h.html#ab1f5637b68fdc1a4d24e4d6275353216", null ],
    [ "ms_mgau_free", "ms__mgau_8h.html#ae553fda1fe6082d50cb95b06a85b2be6", null ],
    [ "ms_mgau_init", "ms__mgau_8h.html#a7dbdcb8e1901665b955e324eefdfeea3", null ],
    [ "ms_mgau_mllr_transform", "ms__mgau_8h.html#ad3fe464ff15e735bfef15e628c5433fc", null ]
];