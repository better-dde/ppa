var structfsg__history__s =
[
    [ "entries", "structfsg__history__s.html#a4f67554340da492c054cccf64adb44ca", null ],
    [ "frame_entries", "structfsg__history__s.html#a45d7ce088233dd4f262d641b7dc7a6b1", null ],
    [ "fsg", "structfsg__history__s.html#a94e0017e3a659d1dbd6be4909d7f0d3a", null ],
    [ "n_ciphone", "structfsg__history__s.html#a23223dcf3542fb87e1c176223aaa4f7d", null ]
];