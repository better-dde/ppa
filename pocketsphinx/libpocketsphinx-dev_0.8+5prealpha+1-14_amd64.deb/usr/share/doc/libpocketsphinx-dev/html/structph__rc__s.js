var structph__rc__s =
[
    [ "next", "structph__rc__s.html#ae05aead721c5cfdd27ac90378bb80f3c", null ],
    [ "pid", "structph__rc__s.html#a9762d0f7b4b9f284fd2b3ff735b4256b", null ],
    [ "rc", "structph__rc__s.html#ab0f0852e254c04a1cb11de805b698733", null ]
];