var structroot__chan__s =
[
    [ "ci2phone", "structroot__chan__s.html#a0c0cf22caf4c97879af86865764f1675", null ],
    [ "ciphone", "structroot__chan__s.html#ad67c37bf4183f518acd7760c09a806f6", null ],
    [ "hmm", "structroot__chan__s.html#a9d4d92ffa8b4079202ddebe3ba0eb290", null ],
    [ "next", "structroot__chan__s.html#ae0f0b90a7cb2fcb54cd7b30502dd497e", null ],
    [ "penult_phn_wid", "structroot__chan__s.html#a9a0db0131f3965ae2eb7dab7e84fc04d", null ],
    [ "this_phn_wid", "structroot__chan__s.html#af5bb41f0c9a03211ab90919f65be1564", null ]
];