var structptm__mgau__s =
[
    [ "base", "structptm__mgau__s.html#ac7ccb744c03564e3c1b360b3436cb3a1", null ],
    [ "config", "structptm__mgau__s.html#aa9cd83ce89052bd6d112ecff54d118f9", null ],
    [ "ds_ratio", "structptm__mgau__s.html#a2254b6ec79c97516b326ad33d22d0050", null ],
    [ "f", "structptm__mgau__s.html#aad0c43234e33c2307ce0df2ddb1c05c9", null ],
    [ "g", "structptm__mgau__s.html#adfba8a590e8d71812ea8082f485e7ad3", null ],
    [ "hist", "structptm__mgau__s.html#a68c75460ebffecc786d7eb2840ed7631", null ],
    [ "lmath", "structptm__mgau__s.html#abbaabfb8678356673a2c0a515e33a378", null ],
    [ "lmath_8b", "structptm__mgau__s.html#ad577181af2afca66f33f1f1e4c576ae8", null ],
    [ "max_topn", "structptm__mgau__s.html#ab397cfdf51d309de4521edc09e80541d", null ],
    [ "mixw", "structptm__mgau__s.html#af0898f6d5b5b863901a4a4858a10d32a", null ],
    [ "mixw_cb", "structptm__mgau__s.html#a5a3c76d47b94978f717a65fa0dfb54e8", null ],
    [ "n_fast_hist", "structptm__mgau__s.html#ac491c223199ed5374dfb13fc41854601", null ],
    [ "n_sen", "structptm__mgau__s.html#ab0f6c452efe082383e906ac2a4f75de4", null ],
    [ "sen2cb", "structptm__mgau__s.html#a5e677255165b8abda63dd1d6dbed1be7", null ],
    [ "sendump_mmap", "structptm__mgau__s.html#a51e0c21f32dd4b13a3fcce320c71e375", null ]
];