var structps__alignment__entry__s =
[
    [ "child", "structps__alignment__entry__s.html#a5f8b29052c7257a83af07018dddb7eff", null ],
    [ "cipid", "structps__alignment__entry__s.html#aff91880bea5aeb787890b1abbf9a3729", null ],
    [ "duration", "structps__alignment__entry__s.html#ad5559bb3e102d94e614d6b0357bda3ad", null ],
    [ "id", "structps__alignment__entry__s.html#a3c41870e66f6813e327a29c1d9b8d3bc", null ],
    [ "parent", "structps__alignment__entry__s.html#aef8dfacf69640a3ff88514298aa8f54a", null ],
    [ "pid", "structps__alignment__entry__s.html#aae4d1a65d8a14cd2db67359fd4658777", null ],
    [ "score", "structps__alignment__entry__s.html#aa43ae9ba4a890fa70c07606165ea4b87", null ],
    [ "senid", "structps__alignment__entry__s.html#a3bcf5a0d3588ee56669e0b5ad3be0ac6", null ],
    [ "ssid", "structps__alignment__entry__s.html#ae82178cb8e2027fd1feeefcc98b53703", null ],
    [ "start", "structps__alignment__entry__s.html#ac3b469463845542c8d29b7c6c4e0f29e", null ],
    [ "tmatid", "structps__alignment__entry__s.html#a25e03c847ee8dc951d105a3555c6cfa3", null ],
    [ "wid", "structps__alignment__entry__s.html#a0e1e8522a0c73c76f1e357f7766fc168", null ]
];