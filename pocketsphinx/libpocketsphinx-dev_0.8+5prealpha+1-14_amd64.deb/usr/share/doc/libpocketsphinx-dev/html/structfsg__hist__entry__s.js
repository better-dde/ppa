var structfsg__hist__entry__s =
[
    [ "frame", "structfsg__hist__entry__s.html#a0788236d846e280b10c8a88a8ae2181c", null ],
    [ "fsglink", "structfsg__hist__entry__s.html#a0bf8f80477f77cbfe5e29bf0de5d58bd", null ],
    [ "lc", "structfsg__hist__entry__s.html#aa3a777338202f23085fb0b445cdb1528", null ],
    [ "pred", "structfsg__hist__entry__s.html#a5fefa055f6b5a6ac976a2a51df426c65", null ],
    [ "rc", "structfsg__hist__entry__s.html#a328d8e1d005360b77b722d1c284b0dc9", null ],
    [ "score", "structfsg__hist__entry__s.html#a45889a875c3146359f2c8019d7c6f534", null ]
];