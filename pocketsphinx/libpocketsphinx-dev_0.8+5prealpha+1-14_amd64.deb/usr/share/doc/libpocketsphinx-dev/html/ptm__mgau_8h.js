var ptm__mgau_8h =
[
    [ "ptm_topn_s", "structptm__topn__s.html", "structptm__topn__s" ],
    [ "ptm_fast_eval_s", "structptm__fast__eval__s.html", "structptm__fast__eval__s" ],
    [ "ptm_mgau_s", "structptm__mgau__s.html", "structptm__mgau__s" ],
    [ "ptm_fast_eval_t", "ptm__mgau_8h.html#af870ed22578ba58631d06a1c01752ced", null ],
    [ "ptm_mgau_t", "ptm__mgau_8h.html#ab1e3230da8b59628476ecdf70e97ec9a", null ],
    [ "ptm_topn_t", "ptm__mgau_8h.html#a4542a2b38a0c0b8ea62432f63fa3c921", null ],
    [ "ptm_mgau_frame_eval", "ptm__mgau_8h.html#ae9fb76ef388e6541bd6c1b20fe8bc094", null ],
    [ "ptm_mgau_free", "ptm__mgau_8h.html#ac202aeb266594ab9c98294a73e16f00a", null ],
    [ "ptm_mgau_init", "ptm__mgau_8h.html#a712679ca84e5b9f7351d969abbe1021a", null ],
    [ "ptm_mgau_mllr_transform", "ptm__mgau_8h.html#ad619b68c9db5e2fed688f62ea4468c4e", null ]
];