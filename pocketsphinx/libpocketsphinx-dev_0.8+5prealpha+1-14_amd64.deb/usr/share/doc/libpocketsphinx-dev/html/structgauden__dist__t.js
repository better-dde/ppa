var structgauden__dist__t =
[
    [ "dist", "structgauden__dist__t.html#ab08100d4953998dad76bfcf30864c0c5", null ],
    [ "id", "structgauden__dist__t.html#a93e978149bae5b5bf089769458c42ee4", null ]
];