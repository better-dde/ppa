var structphone__t =
[
    [ "ci", "structphone__t.html#a0a895c57dccac46699fa3589e42b21d5", null ],
    [ "lc", "structphone__t.html#a2a473afd43114648de71a9444aa54641", null ],
    [ "rc", "structphone__t.html#a334106cbedf3d95a6bdebc4704e028cd", null ],
    [ "ssid", "structphone__t.html#af2f31836358c1c29c38a361b3923b859", null ],
    [ "tmat", "structphone__t.html#acbe38b7fc991bfbcb745fb6131d812f0", null ],
    [ "wpos", "structphone__t.html#a5436db1dd178ef5ead83359c84963c83", null ]
];