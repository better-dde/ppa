var structptm__fast__eval__s =
[
    [ "mgau_active", "structptm__fast__eval__s.html#ac5d3b21239d567b395015d7c4fea157c", null ],
    [ "topn", "structptm__fast__eval__s.html#a95e382028ed8a0af8b56bfcb797af96b", null ]
];