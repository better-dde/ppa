var structvqFeature__s =
[
    [ "codeword", "structvqFeature__s.html#a98d3a78ae272171bd123f41270bec238", null ],
    [ "score", "structvqFeature__s.html#ad1095cdd1efb1a103de8ac96c3c9503c", null ]
];