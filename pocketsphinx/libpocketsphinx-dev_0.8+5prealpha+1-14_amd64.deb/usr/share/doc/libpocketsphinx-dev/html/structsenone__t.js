var structsenone__t =
[
    [ "aw", "structsenone__t.html#ad9b17f6aecf056fcea0eaaab0c7d35ca", null ],
    [ "featscr", "structsenone__t.html#a58af20c262d9d633f53c8c1c7e60459e", null ],
    [ "lmath", "structsenone__t.html#aa8621fab8c5b7a13493cae5549a5e0de", null ],
    [ "mgau", "structsenone__t.html#a5f0eee5a11e7c10b20e0cce10305edfc", null ],
    [ "mixwfloor", "structsenone__t.html#af3f77493f07dd1740084ea8dc4541cb1", null ],
    [ "n_cw", "structsenone__t.html#a3c382a37dc9cb650d910bb881c52b336", null ],
    [ "n_feat", "structsenone__t.html#a6a0aa50b8ff66e06f7305d1c8e4a17be", null ],
    [ "n_gauden", "structsenone__t.html#a71cf7b41b2334216944380296c03c99a", null ],
    [ "n_sen", "structsenone__t.html#a769aa6d2fc16b33c0b9a1cbf31592422", null ],
    [ "pdf", "structsenone__t.html#aa7e23dc8a18875bad1c1b9c322f3cad4", null ]
];