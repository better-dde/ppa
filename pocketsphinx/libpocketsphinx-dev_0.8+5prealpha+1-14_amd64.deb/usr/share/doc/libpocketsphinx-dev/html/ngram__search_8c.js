var ngram__search_8c =
[
    [ "NGRAM_HISTORY_LONG_WORD", "ngram__search_8c.html#af9ad6b3d4ef3ad501da8e2296b25a131", null ],
    [ "dump_bptable", "ngram__search_8c.html#ac10e5308e0a48948b3c21bb4c2d80c1b", null ],
    [ "ngram_compute_seg_score", "ngram__search_8c.html#a7526cf720a80052770c5b6f82c93749d", null ],
    [ "ngram_search_alloc_all_rc", "ngram__search_8c.html#a1ddcc1a9cb3e164ceb2140097ed23a3e", null ],
    [ "ngram_search_bp_hyp", "ngram__search_8c.html#aee393a136f8f7e8b98161e6eed7b1dd9", null ],
    [ "ngram_search_exit_score", "ngram__search_8c.html#a25a80e488425b2bd4e24eb753c9295a5", null ],
    [ "ngram_search_find_exit", "ngram__search_8c.html#aa4b308f06bdf75b2f5eb0f0559f775ae", null ],
    [ "ngram_search_free", "ngram__search_8c.html#aeaf140dc2bbeaa5c274f73480b5328f3", null ],
    [ "ngram_search_free_all_rc", "ngram__search_8c.html#a15477192481dffcb29e9c4167eff6c3c", null ],
    [ "ngram_search_init", "ngram__search_8c.html#a04f80b377c847026254fb85596e2f43c", null ],
    [ "ngram_search_lattice", "ngram__search_8c.html#ac30e7dec4bbfeee9f5163abf4bbd1014", null ],
    [ "ngram_search_mark_bptable", "ngram__search_8c.html#a7772e007b7d7fdf437c87aeb08b59c71", null ],
    [ "ngram_search_save_bp", "ngram__search_8c.html#ae36649be6f5a2190e759e7ed13bd7b6b", null ],
    [ "ngram_search_set_lm", "ngram__search_8c.html#a0e681022d3fa0e63da066aad123245e7", null ]
];