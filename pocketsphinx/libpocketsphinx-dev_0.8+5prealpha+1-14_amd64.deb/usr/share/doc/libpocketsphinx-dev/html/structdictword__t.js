var structdictword__t =
[
    [ "alt", "structdictword__t.html#a84b63cd03706221645f46b2da09e9540", null ],
    [ "basewid", "structdictword__t.html#a53dd72f96a9de21d8925e246cc7c036f", null ],
    [ "ciphone", "structdictword__t.html#acf5836b5a681485868e9090ad67366d5", null ],
    [ "pronlen", "structdictword__t.html#a50509f28a4b64d76519bfadea12f0fa0", null ],
    [ "word", "structdictword__t.html#a3f3371918a406e26817bd4f2cecd7329", null ]
];