var structlatlink__list__s =
[
    [ "link", "structlatlink__list__s.html#accd8f5fdb23871b66b81c830e3808068", null ],
    [ "next", "structlatlink__list__s.html#a17b319bb0f536542267496afecc8de10", null ]
];