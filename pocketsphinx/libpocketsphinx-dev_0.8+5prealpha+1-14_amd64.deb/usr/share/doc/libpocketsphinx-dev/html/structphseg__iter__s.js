var structphseg__iter__s =
[
    [ "base", "structphseg__iter__s.html#a034953404f0e600644b96a9937c206c7", null ],
    [ "seg", "structphseg__iter__s.html#ade35ddbcecdb0ffaad8ee76aba00ef41", null ]
];