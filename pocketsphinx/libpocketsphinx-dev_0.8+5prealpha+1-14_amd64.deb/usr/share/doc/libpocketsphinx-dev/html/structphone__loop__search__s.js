var structphone__loop__search__s =
[
    [ "base", "structphone__loop__search__s.html#aea1cf9ffda814f681b57f32c1f8cc3b1", null ],
    [ "beam", "structphone__loop__search__s.html#a1aa6103c72ce8159bd21bfa4f97feff3", null ],
    [ "best_score", "structphone__loop__search__s.html#af6bf0231db2587a3f7ffa3f838b84db5", null ],
    [ "frame", "structphone__loop__search__s.html#a160e5fb9670d1870e5b21379a87bace5", null ],
    [ "hmmctx", "structphone__loop__search__s.html#a67c44a95de79cb421fbeed4432686f48", null ],
    [ "hmms", "structphone__loop__search__s.html#a6f29f6a259a1ee07108bb55036cec9d0", null ],
    [ "n_phones", "structphone__loop__search__s.html#a7844f45806d19d229504378da16bdc4c", null ],
    [ "pbeam", "structphone__loop__search__s.html#aaace8b677a536e41bb4616e6695b11d3", null ],
    [ "pen_buf", "structphone__loop__search__s.html#ad9233a565738a5097097bab89193e2c5", null ],
    [ "pen_buf_ptr", "structphone__loop__search__s.html#a630510d46979533e7acfd1e70d80ea97", null ],
    [ "penalties", "structphone__loop__search__s.html#a0d01d1eabc94239673b4040e2a6d84fd", null ],
    [ "penalty_weight", "structphone__loop__search__s.html#adecb101bb21afd9e2a32c3f59b5abdc7", null ],
    [ "pip", "structphone__loop__search__s.html#ac979bc57a659c7853eec1854dbcbfabe", null ],
    [ "renorm", "structphone__loop__search__s.html#a273295fbe1a22ad3ddf7db8695a394ec", null ],
    [ "window", "structphone__loop__search__s.html#a28788511ed4729a50c1b475312c7b90a", null ]
];