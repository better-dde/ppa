var structlastphn__cand__s =
[
    [ "bp", "structlastphn__cand__s.html#aa1aeb014f9023a75c81813376115fbcc", null ],
    [ "next", "structlastphn__cand__s.html#a06dade75d757f45e5d43b4869d85bac9", null ],
    [ "score", "structlastphn__cand__s.html#af862094c7b2476c6a66dbc120b19775b", null ],
    [ "wid", "structlastphn__cand__s.html#af8f9fa3e4b6b7e2295d7a437b6f754c3", null ]
];