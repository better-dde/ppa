var structs2__semi__mgau__s =
[
    [ "base", "structs2__semi__mgau__s.html#a9002aae86249006f0b045e5203ec9687", null ],
    [ "config", "structs2__semi__mgau__s.html#ababf1e9522fb14c351df9a6b6d3957bc", null ],
    [ "ds_ratio", "structs2__semi__mgau__s.html#a91b9da8bb484f4552ba0ff47cb262d17", null ],
    [ "f", "structs2__semi__mgau__s.html#ad8cb7f058bcc7402dd6a41c61f1b26e5", null ],
    [ "g", "structs2__semi__mgau__s.html#ab9d5d5dcafa40af8869ceabb60a8d35b", null ],
    [ "lmath", "structs2__semi__mgau__s.html#a8f8f7c72297132fb9a939c9981562ae6", null ],
    [ "lmath_8b", "structs2__semi__mgau__s.html#a1900c90c8ab30d38288fb26b402eb325", null ],
    [ "max_topn", "structs2__semi__mgau__s.html#adda80afc828a938dcdd08f976417d35a", null ],
    [ "mixw", "structs2__semi__mgau__s.html#a1207b5db7e37e9477f3b55cc2d447050", null ],
    [ "mixw_cb", "structs2__semi__mgau__s.html#a20ec32cb8c38fb48909b2cc7c5412c3b", null ],
    [ "n_sen", "structs2__semi__mgau__s.html#a021287621e71f8b74f23197d0efd1e9e", null ],
    [ "n_topn_hist", "structs2__semi__mgau__s.html#a3cbc9fe683da5b7befe6b2712adae327", null ],
    [ "sendump_mmap", "structs2__semi__mgau__s.html#a66a60126fe057d36640cbf69f916bca3", null ],
    [ "topn_beam", "structs2__semi__mgau__s.html#af530876b144ac13df103afe2ccdba2fc", null ],
    [ "topn_hist", "structs2__semi__mgau__s.html#a8892e22acbf81b08972cb6d7968ed4ce", null ],
    [ "topn_hist_n", "structs2__semi__mgau__s.html#acfe1e5d43a25418ef19afba837f85cf7", null ]
];