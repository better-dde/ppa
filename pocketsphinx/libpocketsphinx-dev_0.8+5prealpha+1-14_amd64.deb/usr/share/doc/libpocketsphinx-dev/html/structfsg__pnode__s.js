var structfsg__pnode__s =
[
    [ "alloc_next", "structfsg__pnode__s.html#adbea4e213a25b2c89ba594b7d8c54196", null ],
    [ "ci_ext", "structfsg__pnode__s.html#a961279d7d814232be14050825571fa25", null ],
    [ "ctx", "structfsg__pnode__s.html#a62ddacb58cd22e260f60d6bcef286f6f", null ],
    [ "ctxt", "structfsg__pnode__s.html#abec388a73d3f027103f4dad6d1489a70", null ],
    [ "fsglink", "structfsg__pnode__s.html#a7dfdcda09ced28fcf24d282266eca9de", null ],
    [ "hmm", "structfsg__pnode__s.html#afc1c0ea784c371c8e916df6ab56d81d1", null ],
    [ "leaf", "structfsg__pnode__s.html#a0e14d21465f3c96ae5df22562db52988", null ],
    [ "logs2prob", "structfsg__pnode__s.html#a2f4fd8578c19663f172d66b63d5a3ab7", null ],
    [ "next", "structfsg__pnode__s.html#a7196e1901e221fae9e6b868cfeecd4b8", null ],
    [ "ppos", "structfsg__pnode__s.html#a340a46ef9dfecc230cce91d58c7a1001", null ],
    [ "sibling", "structfsg__pnode__s.html#ad1c7c85e434a067aca06676e84b0ad99", null ],
    [ "succ", "structfsg__pnode__s.html#ab3141209889aed8db432b7dce0d94f12", null ]
];