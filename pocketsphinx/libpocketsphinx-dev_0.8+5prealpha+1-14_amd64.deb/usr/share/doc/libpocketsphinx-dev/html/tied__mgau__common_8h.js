var tied__mgau__common_8h =
[
    [ "GMMADD", "tied__mgau__common_8h.html#a1f6b744cf1ced48452fcb90b5b0ccde2", null ],
    [ "GMMSUB", "tied__mgau__common_8h.html#a740dfe5b30e702ba8b2ec7426bd4d57e", null ],
    [ "LOGMATH_INLINE", "tied__mgau__common_8h.html#a8be78151b3b0ce922541c2755b14ebf1", null ],
    [ "MAX_NEG_ASCR", "tied__mgau__common_8h.html#a965d50d73044c3f2dc2589662fd2e89e", null ],
    [ "MAX_NEG_MIXW", "tied__mgau__common_8h.html#ad739d757ed78293c18dc2386fd3b750e", null ],
    [ "MGAU_MIXW_VERSION", "tied__mgau__common_8h.html#a6b148848668aa5ddeb21f9e5726f8205", null ],
    [ "MGAU_PARAM_VERSION", "tied__mgau__common_8h.html#a14319cfdc013dfddf30896654b6e6500", null ],
    [ "MIN", "tied__mgau__common_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f", null ],
    [ "NONE", "tied__mgau__common_8h.html#a655c84af1b0034986ff56e12e84f983d", null ],
    [ "WORST_DIST", "tied__mgau__common_8h.html#a9512d04e0db6aa7d0c857071935df145", null ],
    [ "fast_logmath_add", "tied__mgau__common_8h.html#a947ea19b4351ecbf70330e089994c3a1", null ]
];