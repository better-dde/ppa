var structngram__search__stats__s =
[
    [ "n_fwdflat_chan", "structngram__search__stats__s.html#ad4717aa85b49d0e0eab0404c316810c6", null ],
    [ "n_fwdflat_word_transition", "structngram__search__stats__s.html#ae308e5217d766e80724fcca1083ac5c7", null ],
    [ "n_fwdflat_words", "structngram__search__stats__s.html#a8cb73a5120ee87ff0044da0f7898a1df", null ],
    [ "n_last_chan_eval", "structngram__search__stats__s.html#a7f19ccd65dc15a2f9c9a78a23c2f2abc", null ],
    [ "n_lastphn_cand_utt", "structngram__search__stats__s.html#a40d598bccdc1a919a0984391b8bd293a", null ],
    [ "n_nonroot_chan_eval", "structngram__search__stats__s.html#a4977b527bbb6a9e0f9961c4ed860f9ee", null ],
    [ "n_phone_eval", "structngram__search__stats__s.html#a853a3fbbba414afebca4250d4bbabcf9", null ],
    [ "n_root_chan_eval", "structngram__search__stats__s.html#afdfb1e063532a44998af60704481e171", null ],
    [ "n_senone_active_utt", "structngram__search__stats__s.html#a08f5c672674fd24943448f0fde8633df", null ],
    [ "n_word_lastchan_eval", "structngram__search__stats__s.html#a7502d4c029445f41e8a1990220d1f503", null ]
];