var structxwdssid__t =
[
    [ "cimap", "structxwdssid__t.html#a502f9241a70383aa260d3390e4ff58fb", null ],
    [ "n_ssid", "structxwdssid__t.html#ab4443c642c5aff57c35abed070112d6e", null ],
    [ "ssid", "structxwdssid__t.html#adbeeda6e94a51f08626c13414cdad6a8", null ]
];