var structcand__sf__t =
[
    [ "bp_ef", "structcand__sf__t.html#ab04890bd8e455c234bf78aec9dab8803", null ],
    [ "cand", "structcand__sf__t.html#a7fcc5ff33fe4ad1a57d1acc272a29f36", null ]
];