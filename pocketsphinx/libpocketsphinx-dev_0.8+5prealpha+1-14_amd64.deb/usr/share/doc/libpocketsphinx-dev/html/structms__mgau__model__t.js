var structms__mgau__model__t =
[
    [ "base", "structms__mgau__model__t.html#a7cf0c4a3c033912a8ab28eb5924fb892", null ],
    [ "config", "structms__mgau__model__t.html#a7ce63c2b0f68a738da9bd3c137c8d0a5", null ],
    [ "dist", "structms__mgau__model__t.html#a07276348bcc1352e45ce61201112fbfa", null ],
    [ "g", "structms__mgau__model__t.html#a91027cdb757280ac557668068e6f1b07", null ],
    [ "mgau_active", "structms__mgau__model__t.html#a1b012fcae279fb82fbb8ec2c11570e89", null ],
    [ "s", "structms__mgau__model__t.html#a551527ce9cd5702d854a1a5600122985", null ],
    [ "topn", "structms__mgau__model__t.html#a0a67ef79bd74c55734b0944f0d61b668", null ]
];