var structfsg__glist__linklist__t =
[
    [ "ci", "structfsg__glist__linklist__t.html#aee967d5f9700245d9bf02f22d730fe86", null ],
    [ "glist", "structfsg__glist__linklist__t.html#a2bc9d5102b5a082d3ece84ac4dca51be", null ],
    [ "next", "structfsg__glist__linklist__t.html#ae6b27b46998d4c2ee400ef828c3cbe57", null ],
    [ "rc", "structfsg__glist__linklist__t.html#ad5fd289a4223f35f2f87b974cbc6bd81", null ]
];