var structfsg__seg__s =
[
    [ "base", "structfsg__seg__s.html#a9f977be4814ec887aadb3cea35f96bab", null ],
    [ "cur", "structfsg__seg__s.html#a4b5e46bf79915c97845974e80355ebbe", null ],
    [ "hist", "structfsg__seg__s.html#ae41fbe837c6c921133c91453c58ba68e", null ],
    [ "n_hist", "structfsg__seg__s.html#aca806a5b88f77803fff4c4c984034515", null ]
];