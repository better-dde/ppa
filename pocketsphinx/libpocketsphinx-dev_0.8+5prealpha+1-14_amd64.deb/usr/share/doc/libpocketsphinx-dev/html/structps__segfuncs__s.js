var structps__segfuncs__s =
[
    [ "seg_free", "structps__segfuncs__s.html#aefbd109d77bf6556b352e5fab721858e", null ],
    [ "seg_next", "structps__segfuncs__s.html#a880757cdcfb8c858dfa82d44259fc8f9", null ]
];