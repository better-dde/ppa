var structlast__ltrans__t =
[
    [ "bp", "structlast__ltrans__t.html#ae42bf37affec23a3f3ea46131aa82c99", null ],
    [ "dscr", "structlast__ltrans__t.html#acef04cbac672e225406402f56002c153", null ],
    [ "sf", "structlast__ltrans__t.html#acaf16ee92b14121c8e357ff4c1c517d7", null ]
];